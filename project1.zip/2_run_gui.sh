cd webservice/ui
npm run dev