cd webservice/server/node-server
node ./server.js